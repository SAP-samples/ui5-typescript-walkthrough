sap.ui.define(["./NavigationJourney"], function (___NavigationJourney) {
  "use strict";
});
