sap.ui.define(["sap/m/Text"], function (Text) {
  "use strict";

  new Text({
    text: "Hello World"
  }).placeAt("content");
});
