sap.ui.define(["./model/formatter"], function (___model_formatter) {
  "use strict";
});
