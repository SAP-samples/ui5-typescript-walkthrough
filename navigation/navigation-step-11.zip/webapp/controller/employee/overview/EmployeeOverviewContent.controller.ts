import SearchField, { SearchField$SearchEvent } from "sap/m/SearchField";
import Table from "sap/m/Table";
import ViewSettingsDialog, { ViewSettingsDialog$ConfirmEvent } from "sap/m/ViewSettingsDialog";
import ViewSettingsItem from "sap/m/ViewSettingsItem";
import BaseController from "ui5/tutorial/navigation/controller/BaseController";
import Filter from "sap/ui/model/Filter";
import FilterOperator from "sap/ui/model/FilterOperator";
import ListBinding from "sap/ui/model/ListBinding";
import Sorter from "sap/ui/model/Sorter";

/**
 * @namespace ui5.tutorial.navigation.controller.employee.overview
 */
export default class EmployeeOverviewContent extends BaseController {

  private table: Table;
  private viewSettingsDialog: ViewSettingsDialog;
  private sortField: string | null = null;
  private sortDescending: boolean = false;
  private validSortFields: string[] = ["EmployeeID", "FirstName", "LastName"];
  private searchQuery: string | null = null;

  public onInit(): void {
    this.table = (<Table> this.byId("employeesTable"));
    this._initViewSettingsDialog();
  }

  public onSortButtonPressed(): void {
    this.viewSettingsDialog.open();
  }

  public onSearchEmployeesTable(event: SearchField$SearchEvent): void {
    this._applySearchFilter(event.getSource().getValue());
  }

  private _initViewSettingsDialog(): void {
    this.viewSettingsDialog = new ViewSettingsDialog("vsd", {
      confirm: (event: ViewSettingsDialog$ConfirmEvent) => {
        const sortItem = event.getParameter("sortItem");
        this._applySorter(sortItem.getKey(), event.getParameter("sortDescending"));
      }
    });

    // init sorting (with simple sorters as custom data for all fields)
    this.viewSettingsDialog.addSortItem(new ViewSettingsItem({
      key: "EmployeeID",
      text: "Employee ID",
      selected: true // by default the MockData is sorted by EmployeeID
    }));

    this.viewSettingsDialog.addSortItem(new ViewSettingsItem({
      key: "FirstName",
      text: "First Name",
      selected: false
    }));

    this.viewSettingsDialog.addSortItem(new ViewSettingsItem({
      key: "LastName",
      text: "Last Name",
      selected: false
    }));
  }

  private _applySearchFilter(searchQuery: string): void {
    // first check if we already have this search value
    if (this.searchQuery === searchQuery) {
      return;
    }
    this.searchQuery = searchQuery;
    (<SearchField> this.byId("searchField")).setValue(searchQuery);

    let filter: Filter | null = null;

    // add filters for search
    if (searchQuery?.length > 0) {
      const filters: Filter[] = [];

      filters.push(new Filter("FirstName", FilterOperator.Contains, searchQuery));
      filters.push(new Filter("LastName", FilterOperator.Contains, searchQuery));
      filter = new Filter({ filters: filters, and: false }); // OR filter
    }

    // update list binding
    const binding = (<ListBinding> this.table.getBinding("items"));
    binding.filter(filter, "Application");
  }

  /**
   * Applies sorting on our table control.
   * @param {string} fieldName the name of the field used for sorting
   * @param {string | boolean} sortDescending true or false as a string or boolean value to specify a descending sorting
   * @private
   */
  private _applySorter(fieldName: string, sortDescending: string | boolean): void {
    // only continue if we have a valid sort field
    if (fieldName && this.validSortFields.includes(fieldName)) {
      let descending: boolean;

      // convert the sort order to a boolean value
      if (typeof sortDescending === "string") {
        descending = sortDescending === "true";
      } else if (typeof sortDescending === "boolean") {
        descending = sortDescending;
      } else {
        descending = false;
      }

      // sort only if the sorter has changed
      if (this.sortField && this.sortField === fieldName && this.sortDescending === descending) {
        return;
      }

      this.sortField = fieldName;
      this.sortDescending = descending;
      const sorter = new Sorter(fieldName, descending);

      // sync with View Settings Dialog
      this._syncViewSettingsDialogSorter(fieldName, descending);

      const binding = (<ListBinding> this.table.getBinding("items"));
      binding.sort(sorter);
    }
  }

  private _syncViewSettingsDialogSorter(sortField: string, sortDescending: boolean): void {
    // the possible keys are: "EmployeeID" | "FirstName" | "LastName"
    // Note: no input validation is implemented here
    this.viewSettingsDialog.setSelectedSortItem(sortField);
    this.viewSettingsDialog.setSortDescending(sortDescending);
  }
}
